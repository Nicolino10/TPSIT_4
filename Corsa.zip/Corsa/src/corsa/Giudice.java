
package corsa;

import java.util.Vector;

/**
 * Giudice è la classe che determina il vincitore
 * @author Andrea Vallorani
 */
public class Giudice extends Thread{
    String[] l = new String[5];
    private Pista pista;
    private String vincitore = "";
    public boolean via = false;
    int conta = 0;
    
    public Giudice(Pista p){
        this.pista = p;
    }
    
    public void run(){
        Atleta a1 = new Atleta("Bonucci",this.pista.bonny,this);                                       
        Atleta a2 = new Atleta("Dani Alves",this.pista.dani,this);
        Atleta a3 = new Atleta("Cuadrado",this.pista.cuadrado,this);
        Atleta a4 = new Atleta("Dybala",this.pista.dybala,this);
        Atleta a5 = new Atleta("Higuain",this.pista.pipita,this);
        a1.start();
        a2.start();
        a3.start();
        a4.start();
        a5.start();
        this.via = true;
        //notifyAll();
        pista.statogara.setText("Gara in corso");
        try{
            a1.join();
            a2.join();
            a3.join();
            a4.join();
            a5.join();
        }
        catch(Exception e){
            
        }
        pista.statogara.setText("Gara terminata!");
        pista.primo.setText("1° : "+l[0]);
        pista.secondo.setText("2° : "+l[1]);
        pista.terzo.setText("3° : "+l[2]);
        pista.quarto.setText("4° : "+l[3]);
        pista.quinto.setText("5° : "+l[4]);
    }
    
    synchronized public void hoFinito(String nomeAtleta){
            this.vincitore = nomeAtleta;
            l[conta] = this.vincitore;
            conta = conta + 1;
    }
    
    public String getVincitore(){
        return this.vincitore;
    }
}
